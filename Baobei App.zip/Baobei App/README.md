# Baobei Complete Split Vite Version

This is a complete standalone Vite + React project.

## Run it

Open this folder in VS Code terminal:
cd "C:\Users\rog\Desktop\7285\DECO2850-7285\Baobei App"
```bash
npm install
npm run dev
```

Refresh: localStorage.removeItem("baobeiOnboardingComplete")

Then open the localhost address Vite gives you.

## Structure

src/
- main.jsx
- App.jsx
- styles.css
- components/
  - Bear.jsx
  - Nav.jsx
  - Header.jsx
  - Activity.jsx
  - Action.jsx
  - Voice.jsx
- pages/
  - Login.jsx
  - Home.jsx
  - Live.jsx
  - Messages.jsx
  - Profile.jsx

The Live Activity page keeps multiple notifications instead of replacing the previous notification.

Arduino is NOT included yet.
